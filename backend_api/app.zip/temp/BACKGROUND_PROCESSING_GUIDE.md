# Background File Processing Usage Guide

## Overview

The `process_file_background` function has been moved to a dedicated service module (`app.services.background_tasks`) to make it reusable across your application. Here are the different ways you can use it:

## 1. Direct Import and Use

```python
from fastapi import BackgroundTasks
from app.services.background_tasks import process_file_background, set_processing_status
from app.models.schemas import ProcessingStatus
import uuid

# In your endpoint
async def my_endpoint(background_tasks: BackgroundTasks, file_content: bytes, filename: str):
    processing_id = str(uuid.uuid4())
    
    # Set initial status
    set_processing_status(processing_id, ProcessingStatus(
        processing_id=processing_id,
        status="pending",
        progress=0.0,
        message="Processing started..."
    ))
    
    # Start background processing
    background_tasks.add_task(
        process_file_background,
        processing_id,
        file_content,
        filename,
        "application/pdf"  # content_type
    )
    
    return {"processing_id": processing_id}
```

## 2. Using Utility Functions

```python
from fastapi import BackgroundTasks
from app.services.processing_utils import process_file_async

# Simplified usage
async def my_endpoint(background_tasks: BackgroundTasks, file_content: bytes, filename: str):
    processing_id = process_file_async(
        background_tasks,
        file_content,
        filename,
        "application/pdf"
    )
    return {"processing_id": processing_id}
```

## 3. Using the BackgroundProcessor Class

```python
from fastapi import BackgroundTasks
from app.services.processing_utils import BackgroundProcessor

async def my_endpoint(background_tasks: BackgroundTasks, file_content: bytes, filename: str):
    # With auto-generated ID
    processing_id = BackgroundProcessor.start_processing(
        background_tasks, file_content, filename, "application/pdf"
    )
    
    # With custom ID
    custom_processing_id = BackgroundProcessor.start_processing(
        background_tasks, file_content, filename, "application/pdf", "my-custom-id"
    )
    
    # Check status
    status = BackgroundProcessor.get_status(processing_id)
    is_done = BackgroundProcessor.is_complete(processing_id)
    is_success = BackgroundProcessor.is_successful(processing_id)
    
    return {"processing_id": processing_id}
```

## 4. Checking Processing Status

```python
from app.services.background_tasks import get_processing_status
from app.services.processing_utils import check_processing_status

# Method 1: Direct from background_tasks
status = get_processing_status(processing_id)

# Method 2: Using utility function (same as above)
status = check_processing_status(processing_id)

if status:
    print(f"Status: {status.status}, Progress: {status.progress}")
```

## 5. Managing Processing Status

```python
from app.services.background_tasks import (
    get_processing_status,
    set_processing_status,
    delete_processing_status,
    get_all_processing_statuses
)

# Get single status
status = get_processing_status("some-id")

# Set/update status
new_status = ProcessingStatus(...)
set_processing_status("some-id", new_status)

# Delete status (cleanup)
delete_processing_status("some-id")

# Get all statuses (for admin/monitoring)
all_statuses = get_all_processing_statuses()
```

## Complete Example: New Endpoint Using Background Processing

```python
from fastapi import APIRouter, BackgroundTasks, UploadFile, File, HTTPException
from app.services.processing_utils import BackgroundProcessor, check_processing_status

router = APIRouter()

@router.post("/my-upload")
async def my_upload_endpoint(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...)
):
    """Custom upload endpoint with background processing"""
    try:
        # Read file
        file_content = await file.read()
        
        # Start processing
        processing_id = BackgroundProcessor.start_processing(
            background_tasks,
            file_content,
            file.filename,
            file.content_type or "application/octet-stream"
        )
        
        return {
            "success": True,
            "processing_id": processing_id,
            "message": "File uploaded and processing started"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/my-status/{processing_id}")
async def get_my_processing_status(processing_id: str):
    """Get processing status"""
    status = check_processing_status(processing_id)
    
    if not status:
        raise HTTPException(status_code=404, detail="Processing ID not found")
    
    return {
        "processing_id": processing_id,
        "status": status.status,
        "progress": status.progress,
        "message": status.message,
        "is_complete": BackgroundProcessor.is_complete(processing_id),
        "is_successful": BackgroundProcessor.is_successful(processing_id),
        "result": status.result if status.status == "completed" else None
    }
```

## Key Benefits

1. **Reusability**: Can be used from any endpoint or service
2. **Consistency**: Same processing logic everywhere
3. **Flexibility**: Multiple ways to use depending on your needs
4. **Maintainability**: Centralized background processing logic
5. **Monitoring**: Easy to track and manage processing status

## Files Created/Modified

- `app/services/background_tasks.py` - Main background processing service
- `app/services/processing_utils.py` - Utility functions and classes
- `app/api/v1/endpoints/examples.py` - Usage examples
- `app/api/v1/endpoints/files.py` - Updated to use the service
