# Quick Docs API Documentation

## Base URL
```
http://localhost:8003
```

## API Endpoints

### 1. Health Check
**GET** `/api/v1/health`

Check if the API is running.

**Response:**
```json
{
  "status": "healthy",
  "message": "Quick Docs API is running"
}
```

**Example:**
```bash
curl http://localhost:8003/api/v1/health
```

---

### 2. File Upload (Synchronous)
**POST** `/api/v1/files/upload-sync`

Upload and process a file immediately. Best for smaller files (< 10MB).

**Request:**
- Content-Type: `multipart/form-data`
- Field: `file` (the file to upload)

**Response:**
```json
{
  "file_id": "uuid-blob-name.pdf",
  "file_url": "http://localhost:8003/mock-storage/uuid-blob-name.pdf",
  "filename": "document.pdf",
  "file_size": 1024000,
  "content_type": "application/pdf",
  "text_extraction": {
    "extracted_text": "Document content here...",
    "text_length": 1500,
    "extraction_method": "PyPDF2"
  },
  "tokenization": {
    "tokens": ["document", "content", "text", "processing", ...],
    "token_count": 250,
    "unique_tokens": 180,
    "method": "basic"
  },
  "processing_time": 2.45,
  "timestamp": "2025-07-11T10:30:00"
}
```

**Example:**
```bash
curl -X POST \
  http://localhost:8003/api/v1/files/upload-sync \
  -H 'Content-Type: multipart/form-data' \
  -F 'file=@/path/to/your/document.pdf'
```

---

### 3. File Upload (Asynchronous)
**POST** `/api/v1/files/upload`

Upload a file for background processing. Best for larger files.

**Request:**
- Content-Type: `multipart/form-data`
- Field: `file` (the file to upload)

**Response:**
```json
{
  "success": true,
  "message": "File uploaded successfully. Processing started.",
  "processing_id": "uuid-processing-id"
}
```

**Example:**
```bash
curl -X POST \
  http://localhost:8003/api/v1/files/upload \
  -H 'Content-Type: multipart/form-data' \
  -F 'file=@/path/to/your/document.pdf'
```

---

### 4. Check Processing Status
**GET** `/api/v1/files/status/{processing_id}`

Check the status of an asynchronously uploaded file.

**Response:**
```json
{
  "processing_id": "uuid-processing-id",
  "status": "completed",  // "pending", "processing", "completed", "failed"
  "progress": 1.0,        // 0.0 to 1.0
  "message": "Processing completed",
  "result": {
    // Same structure as sync upload response
    "file_id": "uuid-blob-name.pdf",
    "file_url": "http://localhost:8003/mock-storage/uuid-blob-name.pdf",
    // ... full result object
  },
  "error": null
}
```

**Example:**
```bash
curl http://localhost:8003/api/v1/files/status/your-processing-id
```

---

### 5. Delete File
**DELETE** `/api/v1/files/file/{file_id}`

Delete a file from storage.

**Response:**
```json
{
  "message": "File deleted successfully"
}
```

**Example:**
```bash
curl -X DELETE http://localhost:8003/api/v1/files/file/uuid-blob-name.pdf
```

---

### 6. API Documentation (Interactive)
**GET** `/docs`

Access the interactive Swagger/OpenAPI documentation.

**Example:**
Open in browser: http://localhost:8003/docs

---

## Supported File Types

- **PDF** (`.pdf`) - Text extraction using PyPDF2
- **Word Documents** (`.docx`) - Text extraction using python-docx  
- **Text Files** (`.txt`) - Direct text reading
- **Legacy Word** (`.doc`) - Limited support

## File Size Limits

- **Synchronous upload**: 10MB
- **Asynchronous upload**: 50MB

## Integration Examples

### Flutter/Dart Integration

```dart
import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';

Future<Map<String, dynamic>> uploadFileSync(String filePath) async {
  final request = http.MultipartRequest(
    'POST',
    Uri.parse('http://localhost:8003/api/v1/files/upload-sync'),
  );
  
  request.files.add(await http.MultipartFile.fromPath('file', filePath));
  
  final response = await request.send();
  final responseBody = await response.stream.bytesToString();
  
  if (response.statusCode == 200) {
    return json.decode(responseBody);
  } else {
    throw Exception('Upload failed: $responseBody');
  }
}

Future<Map<String, dynamic>> uploadFileAsync(String filePath) async {
  final request = http.MultipartRequest(
    'POST',
    Uri.parse('http://localhost:8003/api/v1/files/upload'),
  );
  
  request.files.add(await http.MultipartFile.fromPath('file', filePath));
  
  final response = await request.send();
  final responseBody = await response.stream.bytesToString();
  
  if (response.statusCode == 200) {
    return json.decode(responseBody);
  } else {
    throw Exception('Upload failed: $responseBody');
  }
}

Future<Map<String, dynamic>> checkStatus(String processingId) async {
  final response = await http.get(
    Uri.parse('http://localhost:8003/api/v1/files/status/$processingId'),
  );
  
  if (response.statusCode == 200) {
    return json.decode(response.body);
  } else {
    throw Exception('Status check failed: ${response.body}');
  }
}
```

### Python Integration

```python
import requests
import time

def upload_file_sync(file_path):
    with open(file_path, 'rb') as f:
        files = {'file': f}
        response = requests.post(
            'http://localhost:8003/api/v1/files/upload-sync',
            files=files
        )
    return response.json()

def upload_file_async(file_path):
    with open(file_path, 'rb') as f:
        files = {'file': f}
        response = requests.post(
            'http://localhost:8003/api/v1/files/upload',
            files=files
        )
    return response.json()

def check_status(processing_id):
    response = requests.get(
        f'http://localhost:8003/api/v1/files/status/{processing_id}'
    )
    return response.json()

def wait_for_completion(processing_id, max_wait=300):
    """Wait for async processing to complete"""
    start_time = time.time()
    while time.time() - start_time < max_wait:
        status = check_status(processing_id)
        if status['status'] == 'completed':
            return status['result']
        elif status['status'] == 'failed':
            raise Exception(f"Processing failed: {status.get('error')}")
        time.sleep(2)
    raise Exception("Processing timed out")
```

### JavaScript/Node.js Integration

```javascript
const FormData = require('form-data');
const fs = require('fs');
const axios = require('axios');

async function uploadFileSync(filePath) {
  const form = new FormData();
  form.append('file', fs.createReadStream(filePath));
  
  const response = await axios.post(
    'http://localhost:8003/api/v1/files/upload-sync',
    form,
    { headers: form.getHeaders() }
  );
  
  return response.data;
}

async function uploadFileAsync(filePath) {
  const form = new FormData();
  form.append('file', fs.createReadStream(filePath));
  
  const response = await axios.post(
    'http://localhost:8003/api/v1/files/upload',
    form,
    { headers: form.getHeaders() }
  );
  
  return response.data;
}

async function checkStatus(processingId) {
  const response = await axios.get(
    `http://localhost:8003/api/v1/files/status/${processingId}`
  );
  
  return response.data;
}
```

## Error Handling

### Common Error Responses

**400 Bad Request** - Validation errors
```json
{
  "detail": "File type .exe not supported. Allowed types: ['.pdf', '.txt', '.docx', '.doc']"
}
```

**422 Unprocessable Entity** - Processing errors
```json
{
  "detail": "Text extraction failed: PDF is corrupted"
}
```

**500 Internal Server Error** - Server errors
```json
{
  "detail": "Upload failed: Storage service unavailable"
}
```

## Quick Test Commands

1. **Test health endpoint:**
```bash
curl http://localhost:8003/api/v1/health
```

2. **Create a test file and upload:**
```bash
echo "This is a test document for Quick Docs API." > test.txt
curl -X POST http://localhost:8003/api/v1/files/upload-sync -F 'file=@test.txt'
```

3. **Access interactive docs:**
Open http://localhost:8003/docs in your browser

## Notes

- The API currently uses mock storage (files aren't actually stored in Azure Blob Storage)
- To enable Azure Storage, update the `AZURE_STORAGE_CONNECTION_STRING` in `.env`
- The tokenization currently uses basic tokenization (can be enhanced with spaCy)
- Processing times depend on file size and content complexity
