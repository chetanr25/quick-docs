# Quick Docs FastAPI Backend

A FastAPI backend service for processing documents, extracting text, performing NLP tokenization, and storing files in Azure Blob Storage.

## Features

- **File Upload & Storage**: Upload files to Azure Blob Storage
- **Text Extraction**: Extract text from PDF, DOCX, TXT files
- **NLP Tokenization**: Advanced tokenization using spaCy with fallback to basic tokenization
- **Async Processing**: Background processing for large files
- **RESTful API**: Well-structured REST endpoints
- **Error Handling**: Comprehensive error handling and validation

## Project Structure

```
backend_api/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI application entry point
│   ├── api/
│   │   ├── __init__.py
│   │   └── v1/
│   │       ├── __init__.py
│   │       ├── api.py          # Main API router
│   │       └── endpoints/
│   │           ├── __init__.py
│   │           └── files.py    # File upload/processing endpoints
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py           # Application configuration
│   │   └── exceptions.py       # Custom exceptions
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py          # Pydantic models
│   └── services/
│       ├── __init__.py
│       ├── storage.py          # Azure Blob Storage service
│       ├── file_processing.py  # Text extraction service
│       └── nlp.py              # NLP tokenization service
├── requirements.txt
├── .env.example
└── README.md
```

## Setup

### 1. Install Dependencies

```bash
cd backend_api
pip install -r requirements.txt
```

### 2. Install spaCy Model

```bash
python -m spacy download en_core_web_sm
```

### 3. Environment Configuration

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

Edit `.env` with your Azure Storage connection string:

```env
AZURE_STORAGE_CONNECTION_STRING=your_connection_string_here
AZURE_STORAGE_CONTAINER_NAME=quickdocs
```

### 4. Run the Application

```bash
# Development
uvicorn app.main:app --reload --port 8000

# Production
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## API Endpoints

### File Upload (Async)
- **POST** `/api/v1/files/upload`
- Upload a file for background processing
- Returns processing ID to check status

### File Upload (Sync)
- **POST** `/api/v1/files/upload-sync`
- Upload and process file synchronously
- Returns complete results immediately

### Processing Status
- **GET** `/api/v1/files/status/{processing_id}`
- Check processing status and get results

### Delete File
- **DELETE** `/api/v1/files/file/{file_id}`
- Delete file from Azure Storage

### Health Check
- **GET** `/api/v1/health`
- API health status

## Usage Example

### Upload File (Python)

```python
import requests

# Upload file for async processing
with open("document.pdf", "rb") as f:
    response = requests.post(
        "http://localhost:8000/api/v1/files/upload",
        files={"file": f}
    )
    
processing_id = response.json()["processing_id"]

# Check status
status_response = requests.get(
    f"http://localhost:8000/api/v1/files/status/{processing_id}"
)
```

### Upload File (Flutter/Dart)

```dart
// This integrates with your existing Flutter app
final request = http.MultipartRequest(
  'POST',
  Uri.parse('http://localhost:8000/api/v1/files/upload-sync'),
);

request.files.add(await http.MultipartFile.fromPath('file', filePath));
final response = await request.send();
```

## Response Format

### File Processing Result

```json
{
  "file_id": "uuid-blob-name",
  "file_url": "https://storage.blob.core.windows.net/...",
  "filename": "document.pdf",
  "file_size": 1024000,
  "content_type": "application/pdf",
  "text_extraction": {
    "extracted_text": "Document text content...",
    "text_length": 1500,
    "extraction_method": "PyPDF2"
  },
  "tokenization": {
    "tokens": ["document", "text", "content", ...],
    "token_count": 250,
    "unique_tokens": 180,
    "method": "spacy"
  },
  "processing_time": 2.45,
  "timestamp": 1703123456.789
}
```

## Supported File Types

- PDF (`.pdf`)
- Word Documents (`.docx`)
- Text Files (`.txt`)
- Legacy Word Documents (`.doc`) - Limited support

## Configuration

Key configuration options in `app/core/config.py`:

- `MAX_FILE_SIZE`: Maximum file size (default: 50MB)
- `ALLOWED_FILE_TYPES`: Supported file extensions
- `NLP_MODEL`: spaCy model for tokenization
- `AZURE_STORAGE_*`: Azure Blob Storage settings

## Error Handling

The API provides comprehensive error handling:

- **400**: Validation errors (file type, size, etc.)
- **422**: Processing errors (text extraction, tokenization)
- **500**: Server errors (storage, unexpected errors)

## Development

### Adding New File Types

1. Add MIME type to `FileProcessingService.supported_types`
2. Implement extraction method
3. Update `ALLOWED_FILE_TYPES` in config

### Adding New NLP Features

1. Extend `NLPService` class
2. Add new endpoints in `files.py`
3. Update response models in `schemas.py`

## Production Deployment

1. Use environment variables for all secrets
2. Enable HTTPS
3. Use production WSGI server (Gunicorn)
4. Implement proper logging
5. Add rate limiting
6. Use Redis for processing status storage
7. Add database for persistent storage
