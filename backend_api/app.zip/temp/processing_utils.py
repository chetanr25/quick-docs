# """
# Utility functions for background file processing
# """
# import uuid
# from typing import Optional
# from fastapi import BackgroundTasks

# from app.models.schemas import ProcessingStatus
# class BackgroundProcessor:
#     """Utility class for managing background file processing"""
    
#     @staticmethod
#     def start_processing(
#         background_tasks: BackgroundTasks,
#         file_content: bytes,
#         filename: str,
#         content_type: str,
#         processing_id: Optional[str] = None
#     ) -> str:
#         """
#         Start background processing for a file
        
#         Args:
#             background_tasks: FastAPI BackgroundTasks instance
#             file_content: File content as bytes
#             filename: Name of the file
#             content_type: MIME type of the file
#             processing_id: Optional custom processing ID
            
#         Returns:
#             processing_id: ID to track the processing status
#         """
#         if processing_id is None:
#             processing_id = str(uuid.uuid4())
        
#         # Initialize processing status
#         set_processing_status(processing_id, ProcessingStatus(
#             processing_id=processing_id,
#             status="pending",
#             progress=0.0,
#             message="Processing queued..."
#         ))
        
#         # Add to background tasks
#         background_tasks.add_task(
#             process_file_background,
#             processing_id,
#             file_content,
#             filename,
#             content_type
#         )
        
#         return processing_id
    
#     @staticmethod
#     def get_status(processing_id: str) -> Optional[ProcessingStatus]:
#         """Get processing status by ID"""
#         return get_processing_status(processing_id)
    
#     @staticmethod
#     def is_complete(processing_id: str) -> bool:
#         """Check if processing is complete"""
#         status = get_processing_status(processing_id)
#         return status is not None and status.status in ["completed", "failed"]
    
#     @staticmethod
#     def is_successful(processing_id: str) -> bool:
#         """Check if processing completed successfully"""
#         status = get_processing_status(processing_id)
#         return status is not None and status.status == "completed"


# # Convenience functions for direct use
# def process_file_async(
#     background_tasks: BackgroundTasks,
#     file_content: bytes,
#     filename: str,
#     content_type: str
# ) -> str:
#     """
#     Convenience function to start background file processing
    
#     Returns:
#         processing_id: ID to track the processing status
#     """
#     return BackgroundProcessor.start_processing(
#         background_tasks, file_content, filename, content_type
#     )


# def check_processing_status(processing_id: str) -> Optional[ProcessingStatus]:
#     """
#     Convenience function to check processing status
    
#     Returns:
#         ProcessingStatus or None if not found
#     """
#     return BackgroundProcessor.get_status(processing_id)
