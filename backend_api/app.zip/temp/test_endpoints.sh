#!/bin/bash

# Quick Docs API Test Script

echo "🧪 Testing Quick Docs API on http://localhost:8003"
echo "=================================================="

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test 1: Health Check
echo -e "\n${YELLOW}1. Testing Health Endpoint...${NC}"
curl -s http://localhost:8003/api/v1/health | jq '.' || echo "❌ Health check failed"

# Test 2: Create test file
echo -e "\n${YELLOW}2. Creating test document...${NC}"
cat > test_document.txt << EOF
This is a test document for the Quick Docs API.
It contains various words for tokenization testing:
- Technology: API, backend, frontend, database, server
- Common words: document, text, processing, analysis
- File processing: upload, extract, tokenize, parse
- Sample content for natural language processing and text analysis.

The Quick Docs system can extract text from PDF files, Word documents, and plain text files.
It performs tokenization to break down the text into meaningful tokens for search and analysis.
EOF

echo "✅ Test document created: test_document.txt"

# Test 3: Synchronous Upload
echo -e "\n${YELLOW}3. Testing Synchronous Upload...${NC}"
SYNC_RESULT=$(curl -s -X POST http://localhost:8003/api/v1/files/upload-sync -F 'file=@test_document.txt')
echo "$SYNC_RESULT" | jq '.' || echo "❌ Sync upload failed"

# Extract some info from sync result
if echo "$SYNC_RESULT" | jq -e '.file_id' > /dev/null; then
    FILE_ID=$(echo "$SYNC_RESULT" | jq -r '.file_id')
    TOKEN_COUNT=$(echo "$SYNC_RESULT" | jq -r '.tokenization.token_count')
    TEXT_LENGTH=$(echo "$SYNC_RESULT" | jq -r '.text_extraction.text_length')
    echo -e "${GREEN}✅ Sync upload successful!${NC}"
    echo "   File ID: $FILE_ID"
    echo "   Text Length: $TEXT_LENGTH characters"
    echo "   Token Count: $TOKEN_COUNT tokens"
else
    echo -e "${RED}❌ Sync upload failed${NC}"
fi

# Test 4: Asynchronous Upload
echo -e "\n${YELLOW}4. Testing Asynchronous Upload...${NC}"
ASYNC_RESULT=$(curl -s -X POST http://localhost:8003/api/v1/files/upload -F 'file=@test_document.txt')
echo "$ASYNC_RESULT" | jq '.' || echo "❌ Async upload failed"

# Check processing status
if echo "$ASYNC_RESULT" | jq -e '.processing_id' > /dev/null; then
    PROCESSING_ID=$(echo "$ASYNC_RESULT" | jq -r '.processing_id')
    echo -e "${GREEN}✅ Async upload started!${NC}"
    echo "   Processing ID: $PROCESSING_ID"
    
    # Wait for processing to complete
    echo -e "\n${YELLOW}5. Checking processing status...${NC}"
    for i in {1..10}; do
        sleep 1
        STATUS_RESULT=$(curl -s http://localhost:8003/api/v1/files/status/$PROCESSING_ID)
        STATUS=$(echo "$STATUS_RESULT" | jq -r '.status')
        PROGRESS=$(echo "$STATUS_RESULT" | jq -r '.progress')
        
        echo "   Status: $STATUS - Progress: $(echo "$PROGRESS * 100" | bc -l | cut -d. -f1)%"
        
        if [ "$STATUS" = "completed" ]; then
            echo -e "${GREEN}✅ Async processing completed!${NC}"
            echo "$STATUS_RESULT" | jq '.result' || echo "Result available"
            break
        elif [ "$STATUS" = "failed" ]; then
            echo -e "${RED}❌ Async processing failed${NC}"
            echo "$STATUS_RESULT" | jq '.error'
            break
        fi
    done
else
    echo -e "${RED}❌ Async upload failed${NC}"
fi

# Test 5: API Documentation
echo -e "\n${YELLOW}6. API Documentation Available at:${NC}"
echo "   Interactive Docs: http://localhost:8003/docs"
echo "   JSON Schema: http://localhost:8003/openapi.json"

# Clean up
echo -e "\n${YELLOW}Cleaning up...${NC}"
rm -f test_document.txt
echo "✅ Test file removed"

echo -e "\n${GREEN}🎉 API Testing Complete!${NC}"
echo "=================================================="
echo "Your Quick Docs API is ready to use!"
echo ""
echo "Key endpoints:"
echo "• Health: GET http://localhost:8003/api/v1/health"
echo "• Upload (sync): POST http://localhost:8003/api/v1/files/upload-sync"
echo "• Upload (async): POST http://localhost:8003/api/v1/files/upload"
echo "• Status: GET http://localhost:8003/api/v1/files/status/{id}"
echo "• Docs: http://localhost:8003/docs"
