"""
Simple test script for Quick Docs API
"""
import requests
import json
from pathlib import Path

# API base URL
BASE_URL = "http://localhost:8003/api/v1"

def test_health():
    """Test health endpoint"""
    try:
        response = requests.get(f"{BASE_URL}/health")
        print(f"Health Check: {response.status_code} - {response.json()}")
        return response.status_code == 200
    except Exception as e:
        print(f"Health check failed: {e}")
        return False

def test_file_upload_sync(file_path):
    """Test synchronous file upload"""
    if not Path(file_path).exists():
        print(f"Test file not found: {file_path}")
        return False
    
    try:
        with open(file_path, 'rb') as f:
            files = {'file': f}
            response = requests.post(f"{BASE_URL}/files/upload-sync", files=files)
        
        print(f"File Upload (Sync): {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"✅ File processed successfully!")
            print(f"   File URL: {result['file_url']}")
            print(f"   Text Length: {result['text_extraction']['text_length']}")
            print(f"   Token Count: {result['tokenization']['token_count']}")
            print(f"   Processing Time: {result['processing_time']:.2f}s")
            return True
        else:
            print(f"❌ Upload failed: {response.text}")
            return False
    except Exception as e:
        print(f"Upload test failed: {e}")
        return False

def test_file_upload_async(file_path):
    """Test asynchronous file upload"""
    if not Path(file_path).exists():
        print(f"Test file not found: {file_path}")
        return False
    
    try:
        # Upload file
        with open(file_path, 'rb') as f:
            files = {'file': f}
            response = requests.post(f"{BASE_URL}/files/upload", files=files)
        
        if response.status_code != 200:
            print(f"❌ Async upload failed: {response.text}")
            return False
        
        upload_result = response.json()
        processing_id = upload_result['processing_id']
        print(f"File Upload (Async): {response.status_code}")
        print(f"Processing ID: {processing_id}")
        
        # Check status
        import time
        max_retries = 30
        for i in range(max_retries):
            status_response = requests.get(f"{BASE_URL}/files/status/{processing_id}")
            if status_response.status_code == 200:
                status = status_response.json()
                print(f"Status: {status['status']} - {status['progress']:.1%} - {status.get('message', '')}")
                
                if status['status'] == 'completed':
                    result = status['result']
                    print(f"✅ Async processing completed!")
                    print(f"   File URL: {result['file_url']}")
                    print(f"   Text Length: {result['text_extraction']['text_length']}")
                    print(f"   Token Count: {result['tokenization']['token_count']}")
                    return True
                elif status['status'] == 'failed':
                    print(f"❌ Processing failed: {status.get('error', 'Unknown error')}")
                    return False
            
            time.sleep(2)
        
        print("❌ Processing timed out")
        return False
        
    except Exception as e:
        print(f"Async upload test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🧪 Testing Quick Docs API")
    print("=" * 50)
    
    # Test health
    if not test_health():
        print("❌ API is not running. Please start the server first.")
        return
    
    # Test with a sample text file (create one if needed)
    test_file = "test_document.txt"
    if not Path(test_file).exists():
        with open(test_file, 'w') as f:
            f.write("""
            This is a test document for the Quick Docs API.
            It contains some sample text for testing text extraction and tokenization.
            
            The document includes various words that should be tokenized:
            - Technology terms: API, backend, frontend, database
            - Common words: document, text, sample, testing
            - Numbers and punctuation: 123, test@example.com, www.example.com
            
            This text will be processed to extract tokens and analyze the content.
            """)
        print(f"📄 Created test file: {test_file}")
    
    print("\n🔄 Testing Synchronous Upload...")
    test_file_upload_sync(test_file)
    
    print("\n🔄 Testing Asynchronous Upload...")
    test_file_upload_async(test_file)
    
    print("\n✅ Testing complete!")

if __name__ == "__main__":
    main()
