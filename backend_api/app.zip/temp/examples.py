# """
# backend_api/app/api/v1/endpoints/examples.py
# Example of how to use background processing from other endpoints
# """
# from fastapi import APIRouter, BackgroundTasks, UploadFile, File
# from app.services.processing_utils import process_file_async, check_processing_status
# from app.services.background_tasks import process_file_background

# router = APIRouter()

# # Example 1: Using the utility function
# @router.post("/bulk-upload")
# async def bulk_upload_files(
#     background_tasks: BackgroundTasks,
#     files: list[UploadFile] = File(...)
# ):
#     """Example of processing multiple files using the utility"""
#     processing_ids = []
    
#     for file in files:
#         file_content = await file.read()
#         processing_id = process_file_async(
#             background_tasks,
#             file_content,
#             file.filename,
#             file.content_type or "application/octet-stream"
#         )
#         processing_ids.append(processing_id)
    
#     return {"processing_ids": processing_ids}

# # Example 2: Using the background processor directly
# @router.post("/process-with-custom-id")
# async def process_with_custom_id(
#     background_tasks: BackgroundTasks,
#     file: UploadFile = File(...),
#     custom_id: str = "my-custom-id"
# ):
#     """Example of using custom processing ID"""
#     from app.services.processing_utils import BackgroundProcessor
    
#     file_content = await file.read()
#     processing_id = BackgroundProcessor.start_processing(
#         background_tasks,
#         file_content,
#         file.filename,
#         file.content_type or "application/octet-stream",
#         custom_id
#     )
    
#     return {"processing_id": processing_id}

# # Example 3: Direct use of the background function
# @router.post("/direct-processing")
# async def direct_processing(
#     background_tasks: BackgroundTasks,
#     file: UploadFile = File(...)
# ):
#     """Example of using the background function directly"""
#     import uuid
#     from app.services.background_tasks import set_processing_status
#     from app.models.schemas import ProcessingStatus
    
#     file_content = await file.read()
#     processing_id = str(uuid.uuid4())
    
#     # Set initial status
#     set_processing_status(processing_id, ProcessingStatus(
#         processing_id=processing_id,
#         status="pending",
#         progress=0.0,
#         message="Starting direct processing..."
#     ))
    
#     # Add background task
#     background_tasks.add_task(
#         process_file_background,
#         processing_id,
#         file_content,
#         file.filename,
#         file.content_type or "application/octet-stream"
#     )
    
#     return {"processing_id": processing_id}

# # Example 4: Checking status
# @router.get("/check-status/{processing_id}")
# async def check_status(processing_id: str):
#     """Example of checking processing status"""
#     status = check_processing_status(processing_id)
#     if status is None:
#         return {"error": "Processing ID not found"}
    
#     return {
#         "processing_id": processing_id,
#         "status": status.status,
#         "progress": status.progress,
#         "message": status.message,
#         "completed": status.status in ["completed", "failed"]
#     }
