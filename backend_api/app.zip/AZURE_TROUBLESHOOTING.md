# Azure Storage Troubleshooting Guide

## Issues Fixed in Code

1. **Authentication Configuration**: Improved Azure credential handling
2. **Container Name Bug**: Fixed reference to undefined `self.container_name`
3. **Fallback Behavior**: Removed silent fallback to mock storage
4. **Better Error Handling**: Added comprehensive logging and error messages
5. **Connectivity Testing**: Added health check endpoint

## Cloud Deployment Checklist

### 1. Environment Variables Required

Ensure these environment variables are set in your cloud deployment:

```bash
# Required - Replace with your actual Azure Storage account URL
AZURE_STORAGE_ACCOUNT_URL=https://yourstorageaccount.blob.core.windows.net

# Optional - defaults to "quickdocs"
AZURE_STORAGE_CONTAINER_NAME=quickdocs

# Optional - for connection string based auth (not recommended)
AZURE_STORAGE_CONNECTION_STRING=your_connection_string
```

### 2. Azure Authentication Methods

The app uses `DefaultAzureCredential()` which tries authentication in this order:

1. **Environment Variables** (if connection string is provided)
2. **Managed Identity** (recommended for Azure App Service/Container Apps)
3. **Azure CLI** (for local development)
4. **Visual Studio/VS Code** credentials

### 3. For Different Cloud Platforms

#### Azure App Service / Container Apps
- Enable **System Assigned Managed Identity**
- Grant the managed identity **Storage Blob Data Contributor** role on your storage account
- Set environment variable: `AZURE_STORAGE_ACCOUNT_URL`

#### Azure Container Instances
- Use **User Assigned Managed Identity** or **Service Principal**
- Set environment variables as shown above

#### Other Cloud Platforms (AWS, GCP, etc.)
- Use **Service Principal** authentication
- Set additional environment variables:
```bash
AZURE_CLIENT_ID=your_client_id
AZURE_CLIENT_SECRET=your_client_secret
AZURE_TENANT_ID=your_tenant_id
```

### 4. Testing Your Deployment

1. **Health Check Endpoint**: 
   ```
   GET /api/v1/files/storage-health
   ```
   This will show you:
   - If environment variables are set
   - If Azure client is initialized
   - If connectivity works

2. **Check Logs**: Look for these log messages:
   - "Successfully authenticated with Azure Storage"
   - "Container quickdocs already exists" or "Created container: quickdocs"
   - Any error messages about authentication or connectivity

### 5. Common Issues and Solutions

#### Issue: "Azure Storage Account URL not configured"
**Solution**: Set the `AZURE_STORAGE_ACCOUNT_URL` environment variable

#### Issue: "Authentication failed"
**Solutions**: 
- For Azure App Service: Enable Managed Identity and assign Storage roles
- For other platforms: Set Service Principal credentials

#### Issue: "Container setup failed"
**Solutions**:
- Ensure the storage account exists
- Check that the managed identity/service principal has proper permissions
- Verify the container name doesn't have invalid characters

#### Issue: "Failed to upload file"
**Solutions**:
- Check network connectivity to Azure
- Verify blob storage permissions
- Check if the container exists and is accessible

### 6. Permissions Required

Your authentication method needs these Azure RBAC roles:
- **Storage Blob Data Contributor** (for upload/delete operations)
- **Storage Blob Data Reader** (for read operations)

### 7. Quick Debug Commands

Test your environment variables:
```bash
echo $AZURE_STORAGE_ACCOUNT_URL
echo $AZURE_STORAGE_CONTAINER_NAME
```

Test Azure CLI authentication (if available):
```bash
az storage account list
```

## Sample Environment Configuration

Create a `.env` file for local testing (don't commit to git):

```bash
# Azure Storage Configuration
AZURE_STORAGE_ACCOUNT_URL=https://yourstorageaccount.blob.core.windows.net
AZURE_STORAGE_CONTAINER_NAME=quickdocs

# For Service Principal Authentication (if needed)
# AZURE_CLIENT_ID=your_client_id
# AZURE_CLIENT_SECRET=your_client_secret
# AZURE_TENANT_ID=your_tenant_id

# API Configuration
ALLOWED_HOSTS=*
MAX_FILE_SIZE=52428800
```

## Next Steps

1. Deploy the updated code
2. Set the required environment variables
3. Test the storage health endpoint: `/api/v1/files/storage-health`
4. Check your application logs for any remaining issues
5. Test file upload functionality

If you're still having issues after following this guide, check the application logs and the health endpoint response for specific error details.
